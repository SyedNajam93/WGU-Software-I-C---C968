﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace c968
{
    public static class InputValidator
    {
        // 1. Check if textbox contains only integer numeric input
        public static bool IsNumeric(TextBox textBox)
        {
            if (int.TryParse(textBox.Text, out _))
            {
                return true;
            }
            else
            {
                MessageBox.Show($"Please enter a valid integer value.", 
                    "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox.Focus();
                return false;
            }
        }

        // Check if textbox contains only decimal numeric input
        public static bool IsDecimal(TextBox textBox)
        {
            if (decimal.TryParse(textBox.Text, out _))
            {
                return true;
            }
            else
            {
                MessageBox.Show($"Please enter a valid decimal value.", 
                    "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox.Focus();
                return false;
            }
        }

        // 2. Validate Min, Max, and Inventory range
        public static bool ValidateInventoryRange(int min, int max, int inventory)
        {
            if (min > max)
            {
                MessageBox.Show("Minimum value cannot be greater than Maximum value.", 
                    "Range Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (inventory < min || inventory > max)
            {
                MessageBox.Show("Inventory must be between Min and Max values.", 
                    "Range Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        // 3. Prevent deleting a part that is associated with a product
        public static bool CanDeletePart(Part part, BindingList<Product> products)
        {
            foreach (var product in products)
            {
                if (product.AssociatedParts.Contains(part))
                {
                    MessageBox.Show($"Cannot delete '{part.Name}' because it is associated with product '{product.Name}'.", 
                        "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }

            return true;
        }

        // 4. Confirm before deleting any part or product
        public static bool ConfirmDelete(string itemName)
        {
            var result = MessageBox.Show($"Are you sure you want to delete '{itemName}'?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            return result == DialogResult.Yes;
        }
    }
}
